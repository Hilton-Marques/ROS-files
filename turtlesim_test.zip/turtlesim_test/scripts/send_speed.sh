#!/bin/bash

rostopic pub  /myturtle/turtle1/speed turtlesim_test/Speed -- $1
